create
    definer = root@localhost procedure proc_update(IN id_edit int, IN name_edit varchar(100), IN age_edit int,
                                                   IN sex_edit bit, IN address_edit varchar(255))
begin
    update student set name = name_edit,age=age_edit,sex=sex_edit,address=address_edit where id = id_edit;
end;

