create
    definer = root@localhost procedure test(IN classId int)
begin
    declare total long;
    call  cal_total_students(classId,total);
    select total;
end;

