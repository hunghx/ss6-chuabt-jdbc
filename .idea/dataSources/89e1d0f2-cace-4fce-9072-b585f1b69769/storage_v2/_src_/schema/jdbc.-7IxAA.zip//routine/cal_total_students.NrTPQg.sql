create
    definer = root@localhost procedure cal_total_students(IN classId int, OUT total mediumtext)
begin
    select count(*) into total from student where Student.class_id = classId;
end;

